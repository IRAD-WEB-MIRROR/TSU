Iradi (Latin) TSU-98
Talas State University Computing Centre, revision 3 (2004)

This package contains the Iradi Latin keyboard layout of 1998 for three systems.

  iradi-tsu98.klc        Windows. Open in Microsoft Keyboard Layout Creator 1.4 and choose
                         Project > Build DLL and Setup Package, then run setup.exe.
                         The Computing Centre's own setup.exe for Windows 98 and XP is no longer
                         supported and has been removed. Windows 10 and 11 work with MSKLC.
  Iradi-TSU98.keylayout  Mac OS X. Copy to Library/Keyboard Layouts in your home folder,
                         log out and in, and add "Iradi (Latin) TSU-98" in Input Sources.
  iradi-tsu98.xkb        Linux. Copy to /usr/share/X11/xkb/symbols/iradi and run setxkbmap iradi.

The layout is the US one with the Iradi letters on the right-hand keys:
  ;  -> ş     '  -> ı     [  -> ö     ]  -> ü     \  -> ç     `  -> ñ
  Shift+i gives İ (capital dotted i); Shift+' gives I (capital dotless i).
  Right Alt (AltGr) + a gives ä. AltGr gives back the moved signs: AltGr+; for ";" and so on.
  The full stop and comma are also on the / key, as on the Russian keyboard.
  Shift on the number row follows the Russian keyboard: Shift+2 " , Shift+3 №,
  Shift+4 ; , Shift+6 : , Shift+7 ?. AltGr on those keys gives @ # $ ^ &. AltGr+Shift+4 is €.

Phones: Android and iOS have no Iradi keyboard. Use the Turkish keyboard (ç ş ö ü ı İ)
and the Kyrgyz one for ñ, or long-press n.

Questions: it-help@talasuniversity.org, Computing Centre, main building, room 012.
